# mrsolp Discord — نظام الحياة الواقعية (PS5)

هذا الإصدار لا يستخدم FiveM ولا QBCore. النظام كله يعمل داخل Discord، ومناسب لسيرفر قراند حياة واقعية على السوني.

الأوامر:
- `/materials` موادك: بلاستيك، حديد، حجر، ألمنيوم.
- `/inventory` أغراضك.
- `/craft item` تصنيع Lockpick أو راديو.
- `/addmaterial user material amount` للإدارة لإعطاء المواد.

البيانات محفوظة محليًا في `data/store.json`.

التشغيل:
1. انسخ `.env.example` إلى `.env`.
2. ضع Bot Token وGUILD_ID.
3. `npm install`
4. `npm run deploy`
5. `npm start`

لا ترسل Bot Token لأي شخص.
