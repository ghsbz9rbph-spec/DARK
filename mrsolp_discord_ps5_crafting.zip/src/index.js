require("dotenv").config();
const {Client,GatewayIntentBits,Collection}=require("discord.js");
const fs=require("fs"),path=require("path");
const client=new Client({intents:[GatewayIntentBits.Guilds]});
client.commands=new Collection();
for(const f of fs.readdirSync(path.join(__dirname,"commands")).filter(x=>x.endsWith(".js"))){
 const c=require(path.join(__dirname,"commands",f));client.commands.set(c.data.name,c);
}
client.once("ready",()=>console.log(`mrsolp online: ${client.user.tag}`));
client.on("interactionCreate",async i=>{
 if(!i.isChatInputCommand())return;
 const c=client.commands.get(i.commandName);if(!c)return;
 try{await c.execute(i)}catch(e){console.error(e);if(i.replied||i.deferred)await i.followUp({content:"حدث خطأ.",ephemeral:true});else await i.reply({content:"حدث خطأ.",ephemeral:true});}
});
client.login(process.env.DISCORD_TOKEN);
