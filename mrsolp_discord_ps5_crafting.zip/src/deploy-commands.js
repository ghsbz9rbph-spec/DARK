require("dotenv").config();
const {REST,Routes}=require("discord.js");
const fs=require("fs"),path=require("path");
const commands=[];
for(const f of fs.readdirSync(path.join(__dirname,"commands")).filter(x=>x.endsWith(".js")))commands.push(require(path.join(__dirname,"commands",f)).data.toJSON());
new REST({version:"10"}).setToken(process.env.DISCORD_TOKEN).put(Routes.applicationGuildCommands(process.env.CLIENT_ID,process.env.GUILD_ID),{body:commands}).then(()=>console.log("Commands deployed")).catch(console.error);
