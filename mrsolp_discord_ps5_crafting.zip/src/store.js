const fs=require("fs"),path=require("path");
const file=path.join(__dirname,"..","data","store.json");
function load(){return JSON.parse(fs.readFileSync(file,"utf8"))}
function save(x){fs.writeFileSync(file,JSON.stringify(x,null,2),"utf8")}
function player(id){const x=load();if(!x.players[id])x.players[id]={materials:{plastic:0,iron:0,stone:0,aluminum:0},items:{}};return x.players[id]}
module.exports={load,save,player};